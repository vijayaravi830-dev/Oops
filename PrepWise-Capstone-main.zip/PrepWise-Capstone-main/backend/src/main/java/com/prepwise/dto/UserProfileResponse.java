package com.prepwise.dto;

import com.prepwise.entity.Role;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserProfileResponse {

    private Long id;
    private String name;
    private String email;
    private Role role;
    private Boolean onboardingCompleted;
    private String phone;
    private String avatarUrl;
    private String degree;
    private String branch;
    private String currentSemester;
    private String education;
    private String college;
    private Integer graduationYear;
    private String targetRole;
    private String targetCompany;
    private String preferredIndustry;
    private String placementStatus;
    private String expectedPackage;
    private String preferredLocation;
    private String jobType;
    private String githubUrl;
    private String linkedinUrl;
    private String portfolioUrl;
    private String resumeUrl;
    private String certifications;
    private String targetCompaniesData;
    private String settingsData;
    private String careerGoal;
    private String bio;
    private java.util.List<SkillDto> skills;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
