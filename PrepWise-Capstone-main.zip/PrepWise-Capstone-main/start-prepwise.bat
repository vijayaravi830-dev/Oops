@echo off
setlocal enabledelayedexpansion
title PrepWise Launcher

echo ======================================================================
echo                PrepWise - Full Stack Launcher
echo ======================================================================
echo.

:: 1. Check Node.js & npm
where node >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Node.js is not installed or not found in PATH!
    echo Please install Node.js 18+ from https://nodejs.org/
    echo.
    pause
    exit /b 1
)

where npm >nul 2>&1
if errorlevel 1 (
    echo [ERROR] npm is not installed or not found in PATH!
    echo.
    pause
    exit /b 1
)

:: 2. Check Java
where java >nul 2>&1
if errorlevel 1 (
    echo [WARNING] Java is not detected in PATH. Spring Boot requires Java 17+.
    echo If Java is installed, make sure JAVA_HOME and PATH are configured.
    echo.
)

:: 3. Ensure .env exists
if not exist "%~dp0.env" (
    if exist "%~dp0.env.example" (
        echo [*] Initializing root .env from .env.example...
        copy /y "%~dp0.env.example" "%~dp0.env" >nul
        echo [OK] Created .env file.
    )
)

if not exist "%~dp0backend\.env" (
    if exist "%~dp0.env.example" (
        echo [*] Copying .env to backend\.env...
        copy /y "%~dp0.env.example" "%~dp0backend\.env" >nul
    )
)

:: 4. Check and install frontend dependencies if needed
if not exist "%~dp0node_modules" (
    echo [*] Frontend dependencies missing. Running npm install...
    echo [*] This might take a minute on first run...
    cd /d "%~dp0"
    call npm install
    if errorlevel 1 (
        echo [ERROR] npm install failed. Please check your network and Node installation.
        pause
        exit /b 1
    )
    echo [OK] Frontend dependencies installed successfully.
    echo.
)

:: 5. Display Access URLs
echo ======================================================================
echo   Backend API:      http://localhost:8080
echo   Swagger UI:       http://localhost:8080/swagger-ui.html
echo   Frontend Web App: http://localhost:3000
echo ======================================================================
echo.

:: 6. Launch Backend in a separate window
echo [*] Starting PrepWise Spring Boot Backend in a separate window...
if exist "%~dp0backend\mvnw.cmd" (
    start "PrepWise Backend" cmd /k "cd /d "%~dp0backend" && mvnw.cmd spring-boot:run"
) else (
    start "PrepWise Backend" cmd /k "cd /d "%~dp0backend" && mvn spring-boot:run"
)

:: 7. Wait for Backend initialization & open browser
echo [*] Waiting 6 seconds for backend initialization...
timeout /t 6 /nobreak >nul

echo [*] Opening PrepWise Web App in default browser...
start http://localhost:3000

:: 8. Start Frontend in current window
echo.
echo [*] Starting PrepWise Frontend (Vite dev server)...
echo [*] Press Ctrl+C in this window to stop the frontend.
echo ======================================================================
echo.
cd /d "%~dp0"
call npm run dev

pause
