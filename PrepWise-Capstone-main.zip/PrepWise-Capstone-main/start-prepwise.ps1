# PrepWise PowerShell Launcher
$ErrorActionPreference = "Continue"

Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host "                PrepWise - Full Stack Launcher                        " -ForegroundColor Cyan
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# 1. Environment file setup
if (-not (Test-Path "$ScriptDir\.env") -and (Test-Path "$ScriptDir\.env.example")) {
    Write-Host "[*] Creating .env from .env.example..." -ForegroundColor Yellow
    Copy-Item "$ScriptDir\.env.example" "$ScriptDir\.env"
}
if (-not (Test-Path "$ScriptDir\backend\.env") -and (Test-Path "$ScriptDir\.env.example")) {
    Copy-Item "$ScriptDir\.env.example" "$ScriptDir\backend\.env"
}

# 2. Frontend dependency check
if (-not (Test-Path "$ScriptDir\node_modules")) {
    Write-Host "[*] Installing frontend dependencies (npm install)..." -ForegroundColor Yellow
    Set-Location $ScriptDir
    npm install
}

# 3. Summary
Write-Host "Backend API:      http://localhost:8080" -ForegroundColor Green
Write-Host "Swagger UI:       http://localhost:8080/swagger-ui.html" -ForegroundColor Green
Write-Host "Frontend Web App: http://localhost:3000" -ForegroundColor Green
Write-Host "======================================================================" -ForegroundColor Cyan
Write-Host ""

# 4. Launch Backend
Write-Host "[*] Starting PrepWise Spring Boot Backend in a new window..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-Command", "Set-Location '$ScriptDir\backend'; .\mvnw.cmd spring-boot:run"

# 5. Delay & Launch Browser
Write-Host "[*] Waiting 6 seconds for backend initialization..." -ForegroundColor Yellow
Start-Sleep -Seconds 6

Write-Host "[*] Opening browser to http://localhost:3000..." -ForegroundColor Yellow
Start-Process "http://localhost:3000"

# 6. Start Frontend
Write-Host "[*] Starting PrepWise Frontend..." -ForegroundColor Yellow
Set-Location $ScriptDir
npm run dev
