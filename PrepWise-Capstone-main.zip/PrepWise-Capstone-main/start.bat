@echo off
call "%~dp0start-prepwise.bat"
